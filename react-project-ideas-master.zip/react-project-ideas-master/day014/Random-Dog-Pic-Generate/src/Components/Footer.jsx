import React from 'react'

const Footer = () => {
  return (
    <footer>
    <a href='https://github.com/SPRHackz' title='Github'>&copy; SPR Hackz 2023</a>
  </footer>
  )
}

export default Footer