import Dog from "./Components/Dog" 

function App() {
  return (
    <div className="App">
      <Dog />
    </div>
  );
}

export default App;
